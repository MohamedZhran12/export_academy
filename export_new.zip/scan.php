<?php
// $x=null;
// exec('grep -iR "base64\|str_rot13\|gzuncompress\|eval\|exec\|create_function\|assert\|system(\|stripslashes\|preg_replace (with /e/)\|move_uploaded_file" --include \*.php',$x);
// echo '<pre>';
// print_r($x);
// echo '</pre>';