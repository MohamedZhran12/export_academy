<div class="admin-nav">
  <div class="container-fluid">
    <div class="row">
      <div class="col-sm-3">
        <div class="row">
          <div class="logo">
            <img src="images/logo/Logo (MEA) W.png">
            <i class="fas fa-bars"></i>
          </div>
        </div>
      </div>

      <div class="col-sm-9">
        <div class="background-admin">


          <div class="admin-nav-right">
            <div class="profile-main">
              <div class="profile-image">
                <img src="images/logo/Logo (MEA).jpg">
              </div>


              <div class="profile-text">
                <p><b>Malaysian Export Academy</b></p>
                <p class="small">Settings <i class="fas fa-sort-down"></i></p>
              </div>
              <a class='btn btn-danger btn-sm ml-3' href='logout.php'>Logout</a>
            </div>

            <div class="admin-nav-2">
              <a href="index.php" target="blank" class="navi"><i class="fas fa-globe-asia"></i></a>
              <a href="https://analytics.google.com/analytics/web/?authuser=4#/report-home/a179097857w247676485p229873790"
                 target="blank" class="navi"><i class="fas fa-chart-bar"></i></a>
              <a href="https://hootsuite.com/" target="blank" class="navi"><i class="fas fa-upload"></i></a>
              <a href="https://www.facebook.com/search/top?q=malaysian%20export%20academy" target="blank"
                 class="navi"><i class="fab fa-facebook-f"></i></a>

            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

