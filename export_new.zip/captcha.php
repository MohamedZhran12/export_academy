<script src='https://www.google.com/recaptcha/api.js' async defer></script>
<div class="g-recaptcha" data-callback='enableBtn' data-sitekey="6LeiRZwaAAAAAEb95DV8E8hrwPiFOJr8UTUNVfJi"></div>


<script>
    function enableBtn() {
        document.querySelector('input[type=submit]').removeAttribute('disabled')
    }
</script>