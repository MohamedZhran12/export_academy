<?php
	
	
	ini_set('session.save_path',$sys_config['session_path']);			//	Set session save path
	ini_set('session.cache_expire',0);		//	Time-to-live for cached session pages in minutes
	ini_set('session.cache_limiter','nocache');		//	specifies cache control method to use for session pages
	ini_set('display_errors',0);
													//	(none/nocache/private/private_no_expire/public)
	session_start();
	header("Cache-control: private");	// fix IE form pass back problem

?>