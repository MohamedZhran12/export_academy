<?php
//Maximize script execution time
ini_set('max_execution_time', 0);

//Initial settings, Just specify Source and Destination Image folder.
$ImagesDirectory	= '../source/'; //Source Image Directory End with Slash
$DestImagesDirectory	= '../source/'; //Destination Image Directory End with Slash
$NewImageWidth 		= 1000; //New Width of Image
$NewImageHeight 	= 600; // New Height of Image
$Quality 		= 100; //Image Quality

//Open Source Image directory, loop through each Image and resize it.
if($dir = opendir($ImagesDirectory)){
	while(($file = readdir($dir))!== false){

		$imagePath = $ImagesDirectory.$file;
		$destPath = $DestImagesDirectory.$file;
		$checkValidImage = @getimagesize($imagePath);

		if(file_exists($imagePath) && $checkValidImage) //Continue only if 2 given parameters are true
		{
			//Image looks valid, resize.
			if(resizeImage($imagePath,$destPath,$NewImageWidth,$NewImageHeight,$Quality))
			{
				echo $file.' resize Success!<br />';
				/*
				Now Image is resized, may be save information in database?
				*/

			}
else{
echo $file.' Succesfully Uploaded!<br />';
}
		}
	}
	closedir($dir);
}

//Function that resizes image.
function resizeImage($SrcImage,$DestImage, $MaxWidth,$MaxHeight,$Quality)
{
   	list($iWidth,$iHeight,$type)	= getimagesize($SrcImage);
    $ImageScale          	= min($MaxWidth/$iWidth, $MaxHeight/$iHeight);
    $NewWidth              	= ceil($ImageScale*$iWidth);
    $NewHeight             	= ceil($ImageScale*$iHeight);
    $NewCanves             	= imagecreatetruecolor($NewWidth, $NewHeight);

	switch(strtolower(image_type_to_mime_type($type)))
	{
		case 'image/jpeg':
			$NewImage = imagecreatefromjpeg($SrcImage);
			break;
		case 'image/png':
			$NewImage = imagecreatefrompng($SrcImage);
			break;
		case 'image/gif':
			$NewImage = imagecreatefromgif($SrcImage);
			break;
		default:
			return false;
	}


	// Resize Image
    if(imagecopyresampled($NewCanves, $NewImage,0, 0, 0, 0, $NewWidth, $NewHeight, $iWidth, $iHeight))
    {
        // copy file
        if(imagejpeg($NewCanves,$DestImage,$Quality))
        {
            imagedestroy($NewCanves);
            return true;
        }
    }
}


$source = "source";
$destination = "../images/gallery/";

$watermark = imagecreatefrompng("watermark.png");

$margin_right = 30;
$margin_bottom = 30;

$sx = imagesx($watermark);
$sy = imagesy($watermark);

$images = array_diff(scandir($source), array('..','.'));

foreach ($images as $image) {
$img = imagecreatefromjpeg($source.'/'.$image);
imagecopy($img, $watermark, imagesx($img) - $sx - $margin_right, imagesy($img) - $sy - $margin_bottom, 0, 0, $sx, $sy);

$i = imagejpeg($img, $destination.'/'.$image, 100);
imagedestroy($img);
}


$files = glob('source/*.jpg');
foreach($files as $file) {
    unlink($file);
}

	$result = mysql_query($sql);
    echo '
	<script type="text/javascript">alert("Successfully Upload Galleries!");
	location.href="admin-upload-album.php";
	</script>';	

?>

