<?php
require_once('adminheader.php');
require_once('adminnav.php');

include "config.php";

if (isset($_POST['submit'])) {

  // Count total files
  $countfiles = count($_FILES['files']['name']);

  // Prepared statement
  $query = "INSERT INTO images_list (name,location,sys_album_id)
			VALUES (?,?,'" . $_POST["albumid"] . "')";
  $statement  = $conn->prepare($query);

  // Loop all files
  for ($i = 0; $i < $countfiles; $i++) {

    // File name
    $strtotime = strtotime("now");
    $filename = $strtotime . '_' . $_FILES['files']['name'][$i];
    $albumid = $_POST['albumid'];

    // Get extension
    $ext = end((explode(".", $filename)));

    // Valid image extension
    $valid_ext = array("png", "jpeg", "jpg");

    if (in_array($ext, $valid_ext)) {

      $rawBaseName = pathinfo($name, PATHINFO_FILENAME);
      $extension = pathinfo($name, PATHINFO_EXTENSION);
      $counter = 0;
      while (file_exists("filer/" . $albumid . "/" . $name)) {
        $fname = $rawBaseName . $counter . '.' . $extension;
        $counter++;
      };



      // Upload file
      if (move_uploaded_file($_FILES['files']['tmp_name'][$i], 'source/' . $filename)) {

        // Execute query
        $statement->execute(array($filename, 'admin/images/gallery/' . $filename));
      }
    }
  }

  $result = mysql_query($sql);
  echo '
	<script type="text/javascript">alert("Successfully Upload Galleries!");
	location.href="admin-add-watermark.php";
	</script>';
} ?>


<?php
$source = "uploads";
$destination = "uploads";

$watermark = imagecreatefrompng("watermark.png");

$margin_right = 30;
$margin_bottom = 30;

$sx = imagesx($watermark);
$sy = imagesy($watermark);

$images = array_diff(scandir($source), array('..', '.'));

foreach ($images as $image) {
  $img = imagecreatefromjpeg($source . '/' . $image);
  imagecopy($img, $watermark, imagesx($img) - $sx - $margin_right, imagesy($img) - $sy - $margin_bottom, 0, 0, $sx, $sy);

  $i = imagejpeg($img, $destination . '/' . $image, 100);
  imagedestroy($img);
}
?>


<div class="margin-top"></div>


<div class="container-fluid">
  <div class="row">
    <?php
    require_once('admin-sidebar.php');
    ?>

    <div class="col-10">
      <div class="padding-30-15">
        <div class="breadcrumb-main">
          <p class="current-link">Admin Dashboard</p>
          <i class="fas fa-chevron-right"></i>
          <p class="current-link">Upload Galleries</p>
        </div>
        <br>






        <div class="row">
          <div class="col-10">
            <div class="margin-bottom-30">
              <div class="background-white">
                <div class="padding-topic">
                  <p class="menu-topic">Upload Galleries</p>
                </div>
                <hr>


                <div class="row">
                  <div class="col-sm-4">
                    <p class="admin-topic-in"><i class="fas fa-images"></i> New Album Uploaded</p>
                  </div>

                  <?php
                  global $conn;
                  $sql = $conn->prepare("SELECT * FROM sys_album ORDER BY sys_album_id DESC LIMIT 1");
                  $sql->execute([]);
                  if ($sql->rowCount() > 0) {
                    foreach ($sql->fetchAll() as $row) {
                  ?>
                      <div class="admin-new-album">
                        <div class="admin-img-overflow">
                          <img src="images/album/<?php echo $row['sys_album_image']; ?>" />
                        </div>
                        <div class="admin-new-det">
                          <p>Album ID : <?php echo $row['sys_album_id']; ?></p>
                          <p>Name : <?php echo $row['sys_album_name']; ?></p>
                          <p class="admin-new-type">Type : <?php echo $row['cat_id']; ?></p>
                          <p>Place : <?php echo $row['sys_album_place']; ?></p>
                        </div>

                      </div>
                  <?php }
                  } ?>
                </div>


                <div class="col-sm-12">
                  <div class="padding-30">
                    <div class="row">


                      <?php
                      $sql = $conn->prepare("SELECT usr_fullname, usr_email, usr_mobile FROM sys_user WHERE usr_id = ?");
                      $sql->execute([$_GET['id']]);
                      $row = $sql->fetch();
                      ?>

                      <form method='post' action='' enctype='multipart/form-data'>
                        <input type='file' name='files[]' multiple />

                        <?php
                        $sql = $conn->prepare("SELECT * FROM sys_album ORDER BY sys_album_id DESC LIMIT 1");
                        $sql->execute([]);
                        if ($sql->rowCount() > 0) {
                          foreach ($sql->fetchAll() as $row) {
                        ?>
                            <input type="hidden" name="albumid" value="<?php echo $row['sys_album_id']; ?>">
                        <?php }
                        } ?>

                        <br><br>
                        <input type='submit' value='Submit' name='submit' />
                      </form>


                    </div>
                  </div>
                </div>
              </div>



            </div>
          </div>
        </div>
      </div>
    </div>
  </div>














  <script>
    jQuery(document).ready(function($) {
      $('.wiggle-bug .bug').hover(function() {
        $(this).addClass('animated infinite tada');
      }, function() {
        $(this).removeClass('animated infinite tada');
      });

      $('.wiggle-bug').click(function() {
        $(this).find('.bug').toggle('explode');
      });
    });
  </script>












  <!-- Optional JavaScript -->
  <!-- jQuery first, then Popper.js, then Bootstrap JS -->
  <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js" integrity="sha384-wHAiFfRlMFy6i5SRaxvfOCifBUQy1xHdJ/yoi7FRNXMRBu5WHdZYu1hA6ZOblgut" crossorigin="anonymous"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js" integrity="sha384-B0UglyR+jN6CkvvICOB2joaf5I4l3gm9GU6Hc1og6Ls7i6U/mkkaduKaBhlAXv9k" crossorigin="anonymous"></script>

  <!--<link rel="stylesheet" type="text/css" href="adminnew.css">-->

  <!--font-->
  <link href="https://fonts.googleapis.com/css?family=Didact+Gothic|Julius+Sans+One|Questrial" rel="stylesheet">

  <!--font awesome-->
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css" integrity="sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ" crossorigin="anonymous">
  </body>

  </html>
