        <div class="col-2"> 
        <div class="row">
        <div class="background-gradient">
        <div class="side-bar-menu">
        <p>Menu</p>
            <a href="#" class="side-menu-link">Admin Dashboard</a>
            <a href="#" class="side-menu-link">Upload Course</a>
            <a href="#" class="side-menu-link">Upload Course</a>
            <a href="#" class="side-menu-link">Upload Course</a>
            <a href="#" class="side-menu-link">Upload Course</a>
        </div>
        </div>
        </div>
        
    </div>